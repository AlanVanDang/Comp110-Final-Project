"""Utility functions for wrangling data."""

__author__ = "730390548"


from csv import DictReader
import pandas as pd


def read_csv_rows(csv_file: str) -> list[dict[str, str]]:
    """Read a CSV file's contents into a list of rows."""
    rows: list[dict[str, str]] = []

    file_handle = open(csv_file)
    csv_reader = DictReader(file_handle)

    for line in csv_reader:
        rows.append(line)

    file_handle.close()

    return rows


def column_values(data_rows: list[dict[str, str]], category: str) -> list[str]:
    """Finding a column list from a list of rows."""
    columns: list[str] = []

    for row in data_rows:
        columns.append(row[category])

    return columns


def columnar(data_rows: list[dict[str, str]]) -> dict[str, list[str]]:
    """Transfrom a table of rows into a dictionary of columns."""
    new_column: dict[str, list[str]] = {}
    new_column = pd.DataFrame(data_rows)

    return new_column


def head(column_table: dict[str, list[str]], number_of_rows: int) -> dict[str, list[str]]:
    """New Column with only the first N rows of data for each column."""
    empty_dictionary: dict[str, list[str]] = {}
    i = 0
    while i < number_of_rows:
        for row in column_table:
            empty_dictionary[row] = column_table[row]
            i += 1
    
    return empty_dictionary


def select(column_table: dict[str, list[str]], name_of_column: list[str]) -> dict[str, list[str]]:
    """Select's specific columns."""
    selective_dictionary: dict[str, list[str]] = {}
    
    for columns in name_of_column:
        selective_dictionary[columns] = column_table[columns]

    return selective_dictionary


def count(values: list[str],) -> dict[str, int]:
    """Counts the number of items with the word associated with it."""
    counting_dictionary: dict[str, int] = {}
    
    for line in values:
        if line in counting_dictionary:
            counting_dictionary[line] += 1
        else:
            counting_dictionary[line] = 1

    return counting_dictionary